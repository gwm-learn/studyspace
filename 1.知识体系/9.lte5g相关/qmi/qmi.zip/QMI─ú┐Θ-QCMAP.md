# QCMAP
Qualcomm Mobile Access Point Service   

QMI_QCMAP提供一个命令集，用于与无线移动站连接以访问移动AP服务   



