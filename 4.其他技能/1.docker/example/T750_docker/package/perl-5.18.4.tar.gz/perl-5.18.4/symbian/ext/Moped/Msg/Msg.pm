package Moped::Msg;
use strict;
use vars qw(@ISA $VERSION);
require DynaLoader;
@ISA = qw(DynaLoader);
$VERSION = '0.01';
bootstrap Moped::Msg;
1;

